package com.aicoder.ide.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

data class ProjectNode(
    val name: String,
    val uri: Uri,
    val isDirectory: Boolean,
    val depth: Int
)

/**
 * Wraps a Storage-Access-Framework directory tree so the app (and the AI)
 * can list, read, write, create and delete files inside the folder the
 * user picked, without needing broad filesystem permissions.
 */
class ProjectFiles(private val context: Context) {

    var rootUri: Uri? = null
        private set

    fun openTree(uri: Uri) {
        context.contentResolver.takePersistableUriPermission(
            uri,
            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        rootUri = uri
    }

    fun rootName(): String {
        val root = rootUri ?: return ""
        return DocumentFile.fromTreeUri(context, root)?.name ?: ""
    }

    /** Flattened, depth-first listing of the whole tree (used for the drawer + AI context). */
    fun listAll(): List<ProjectNode> {
        val root = rootUri ?: return emptyList()
        val rootDoc = DocumentFile.fromTreeUri(context, root) ?: return emptyList()
        val result = mutableListOf<ProjectNode>()
        fun walk(doc: DocumentFile, depth: Int) {
            doc.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name ?: "" })).forEach { child ->
                result.add(ProjectNode(child.name ?: "?", child.uri, child.isDirectory, depth))
                if (child.isDirectory && depth < 6) walk(child, depth + 1)
            }
        }
        walk(rootDoc, 0)
        return result
    }

    fun readFile(uri: Uri): String {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "cannot open $uri" }
            BufferedReader(InputStreamReader(input)).use { return it.readText() }
        }
    }

    fun writeFile(uri: Uri, content: String) {
        context.contentResolver.openOutputStream(uri, "wt").use { output ->
            requireNotNull(output) { "cannot open $uri for writing" }
            OutputStreamWriter(output).use { it.write(content) }
        }
    }

    fun deleteFile(uri: Uri): Boolean {
        return DocumentFile.fromSingleUri(context, uri)?.delete() ?: false
    }

    /** Creates a new file at a "a/b/c.txt"-style relative path under the root, making folders as needed. */
    fun createFile(relativePath: String, content: String): Uri {
        val root = rootUri ?: error("no directory open")
        var dir = DocumentFile.fromTreeUri(context, root) ?: error("bad root")
        val parts = relativePath.trim('/').split("/")
        for (i in 0 until parts.size - 1) {
            val name = parts[i]
            dir = dir.findFile(name)?.takeIf { it.isDirectory } ?: dir.createDirectory(name) ?: error("cannot create dir $name")
        }
        val fileName = parts.last()
        val existing = dir.findFile(fileName)
        val file = existing ?: dir.createFile(guessMime(fileName), fileName) ?: error("cannot create file $fileName")
        writeFile(file.uri, content)
        return file.uri
    }

    /** Finds a file's Uri by its relative "a/b/c.txt" path from the root, or null. */
    fun findByRelativePath(relativePath: String): Uri? {
        val root = rootUri ?: return null
        var dir: DocumentFile = DocumentFile.fromTreeUri(context, root) ?: return null
        val parts = relativePath.trim('/').split("/")
        for (i in 0 until parts.size - 1) {
            dir = dir.findFile(parts[i]) ?: return null
        }
        return dir.findFile(parts.last())?.uri
    }

    private fun guessMime(fileName: String): String {
        return when (fileName.substringAfterLast('.', "")) {
            "json" -> "application/json"
            "xml" -> "text/xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            else -> "text/plain"
        }
    }
}
