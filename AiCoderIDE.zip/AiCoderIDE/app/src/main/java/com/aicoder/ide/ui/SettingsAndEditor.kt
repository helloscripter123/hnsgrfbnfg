package com.aicoder.ide.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aicoder.ide.R
import com.aicoder.ide.data.Provider
import com.aicoder.ide.data.ProviderPresets

private val TextMain = Color(0xFFE6E6EF)
private val TextMuted = Color(0xFF9090A0)
private val AccentBlue = Color(0xFF7C9BFF)
private val SurfaceDark = Color(0xFF1E1E2A)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    state: UiState,
    onDismiss: () -> Unit,
    onAddProvider: (String, String, String, List<String>) -> Unit,
    onRemoveProvider: (String) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SurfaceDark) {
        Column(Modifier.fillMaxWidth().padding(16.dp).heightIn(max = 560.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Провайдеры ИИ", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { showAddDialog = true }) { SvgIcon(R.drawable.ic_add, Modifier.size(20.dp)) }
            }
            Spacer(Modifier.height(8.dp))

            if (state.providers.isEmpty()) {
                Text("Провайдеры не добавлены. Нажмите + чтобы добавить OpenAI, Groq, OpenRouter или свой сервер.", color = TextMuted, fontSize = 13.sp)
            } else {
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    items(state.providers) { p ->
                        ProviderRow(p, onRemove = { onRemoveProvider(p.id) })
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Divider(color = Color(0xFF2A2A38))
            Spacer(Modifier.height(8.dp))
            Text("Ключи API хранятся только локально на устройстве.", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
        }
    }

    if (showAddDialog) {
        AddProviderDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, url, key, models ->
                onAddProvider(name, url, key, models)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun ProviderRow(provider: Provider, onRemove: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF23232E))
            .padding(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(provider.name, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(provider.baseUrl, color = TextMuted, fontSize = 11.sp)
            Text("${provider.models.size} моделей", color = TextMuted, fontSize = 11.sp)
        }
        IconButton(onClick = onRemove) { SvgIcon(R.drawable.ic_delete, Modifier.size(18.dp)) }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun AddProviderDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String, List<String>) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var modelsText by remember { mutableStateOf("") }

    fun applyPreset(p: Provider) {
        name = p.name
        baseUrl = p.baseUrl
        modelsText = p.models.joinToString(", ")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить провайдера") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Быстрый выбор:", fontSize = 12.sp, color = TextMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                    ProviderPresets.ALL.forEach { preset ->
                        AssistChip(onClick = { applyPreset(preset) }, label = { Text(preset.name, fontSize = 11.sp) })
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL (…/v1)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("API ключ") },
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
                OutlinedTextField(
                    value = modelsText,
                    onValueChange = { modelsText = it },
                    label = { Text("Модели (через запятую)") },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val models = modelsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (name.isNotBlank() && baseUrl.isNotBlank() && models.isNotEmpty()) {
                    onAdd(name.trim(), baseUrl.trim(), apiKey.trim(), models)
                }
            }) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun FileEditorDialog(
    fileName: String,
    content: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember(fileName) { mutableStateOf(content) }
    LaunchedEffect(content) { text = content }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .clip(RoundedCornerShape(14.dp))
                .background(SurfaceDark)
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SvgIcon(R.drawable.ic_file, Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(fileName, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { SvgIcon(R.drawable.ic_close, Modifier.size(18.dp)) }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f).fillMaxWidth(),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = TextMain)
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onDismiss) { Text("Закрыть") }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { onSave(text) },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                ) {
                    SvgIcon(R.drawable.ic_check, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Сохранить")
                }
            }
        }
    }
}
