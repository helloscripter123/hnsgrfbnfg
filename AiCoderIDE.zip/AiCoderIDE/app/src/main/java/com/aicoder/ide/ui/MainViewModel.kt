package com.aicoder.ide.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aicoder.ide.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class UiState(
    val providers: List<Provider> = emptyList(),
    val selectedProviderId: String? = null,
    val selectedModel: String? = null,
    val mode: AiMode = AiMode.BUILD,
    val internetEnabled: Boolean = false,
    val messages: List<ChatMessage> = emptyList(),
    val isSending: Boolean = false,
    val inputText: String = "",
    val attachedFileName: String? = null,
    val attachedFileContent: String? = null,
    val projectOpen: Boolean = false,
    val projectRootName: String = "",
    val projectNodes: List<ProjectNode> = emptyList(),
    val drawerOpen: Boolean = false,
    val settingsOpen: Boolean = false,
    val openFileUri: Uri? = null,
    val openFileName: String? = null,
    val openFileContent: String = "",
    val errorMessage: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val providerStore = ProviderStore(app)
    private val projectFiles = ProjectFiles(app)
    private val aiRepository = AiRepository()

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    init {
        val providers = providerStore.loadProviders()
        val selected = providerStore.getSelectedModelKey()?.split("::")
        _state.update {
            it.copy(
                providers = providers,
                selectedProviderId = selected?.getOrNull(0) ?: providers.firstOrNull()?.id,
                selectedModel = selected?.getOrNull(1) ?: providers.firstOrNull()?.models?.firstOrNull()
            )
        }
    }

    // ---------- Providers ----------

    fun addProvider(name: String, baseUrl: String, apiKey: String, models: List<String>) {
        val newProvider = Provider(UUID.randomUUID().toString(), name, baseUrl, apiKey, models)
        val updated = _state.value.providers + newProvider
        providerStore.saveProviders(updated)
        _state.update {
            it.copy(
                providers = updated,
                selectedProviderId = it.selectedProviderId ?: newProvider.id,
                selectedModel = it.selectedModel ?: newProvider.models.firstOrNull()
            )
        }
    }

    fun removeProvider(providerId: String) {
        val updated = _state.value.providers.filterNot { it.id == providerId }
        providerStore.saveProviders(updated)
        _state.update {
            val stillSelected = if (it.selectedProviderId == providerId) updated.firstOrNull()?.id else it.selectedProviderId
            it.copy(providers = updated, selectedProviderId = stillSelected)
        }
    }

    fun selectModel(providerId: String, model: String) {
        providerStore.setSelectedModelKey(providerId, model)
        _state.update { it.copy(selectedProviderId = providerId, selectedModel = model) }
    }

    fun setMode(mode: AiMode) = _state.update { it.copy(mode = mode) }

    fun toggleInternet() = _state.update { it.copy(internetEnabled = !it.internetEnabled) }

    fun toggleDrawer() = _state.update { it.copy(drawerOpen = !it.drawerOpen) }

    fun openSettings(open: Boolean) = _state.update { it.copy(settingsOpen = open) }

    fun onInputChange(text: String) = _state.update { it.copy(inputText = text) }

    fun clearError() = _state.update { it.copy(errorMessage = null) }

    // ---------- Project directory ----------

    fun openDirectory(uri: Uri) {
        projectFiles.openTree(uri)
        providerStore.setSavedTreeUri(uri.toString())
        refreshProjectTree()
    }

    fun restoreSavedDirectory() {
        val saved = providerStore.getSavedTreeUri() ?: return
        try {
            projectFiles.openTree(Uri.parse(saved))
            refreshProjectTree()
        } catch (_: Exception) {
            // permission may have been revoked; user can reopen it manually
        }
    }

    private fun refreshProjectTree() {
        val nodes = projectFiles.listAll()
        _state.update {
            it.copy(
                projectOpen = true,
                projectRootName = projectFiles.rootName(),
                projectNodes = nodes
            )
        }
    }

    fun openFileForViewing(uri: Uri, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val content = try {
                projectFiles.readFile(uri)
            } catch (e: Exception) {
                "// не удалось прочитать файл: ${e.message}"
            }
            _state.update { it.copy(openFileUri = uri, openFileName = name, openFileContent = content) }
        }
    }

    fun closeFileViewer() = _state.update { it.copy(openFileUri = null, openFileName = null, openFileContent = "") }

    fun saveOpenFile(newContent: String) {
        val uri = _state.value.openFileUri ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                projectFiles.writeFile(uri, newContent)
                _state.update { it.copy(openFileContent = newContent) }
            } catch (e: Exception) {
                _state.update { it.copy(errorMessage = "Ошибка сохранения: ${e.message}") }
            }
        }
    }

    fun deleteNode(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            projectFiles.deleteFile(uri)
            refreshProjectTree()
        }
    }

    fun createNewFile(relativePath: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                projectFiles.createFile(relativePath, "")
                refreshProjectTree()
            } catch (e: Exception) {
                _state.update { it.copy(errorMessage = "Ошибка создания файла: ${e.message}") }
            }
        }
    }

    // ---------- Attachments ----------

    fun attachFile(name: String, content: String) {
        _state.update { it.copy(attachedFileName = name, attachedFileContent = content) }
    }

    fun clearAttachment() = _state.update { it.copy(attachedFileName = null, attachedFileContent = null) }

    // ---------- Chat ----------

    fun sendMessage() {
        val s = _state.value
        val text = s.inputText.trim()
        if (text.isEmpty() || s.isSending) return
        val provider = s.providers.find { it.id == s.selectedProviderId }
        if (provider == null) {
            _state.update { it.copy(errorMessage = "Сначала добавьте провайдера ИИ в настройках.") }
            return
        }
        val model = s.selectedModel ?: provider.models.firstOrNull()
        if (model == null) {
            _state.update { it.copy(errorMessage = "Выберите модель.") }
            return
        }

        val userMessageText = buildString {
            append(text)
            if (s.attachedFileContent != null) {
                append("\n\n[Прикреплённый файл: ${s.attachedFileName}]\n```\n")
                append(s.attachedFileContent.take(6000))
                append("\n```")
            }
        }

        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            role = Role.USER,
            text = userMessageText,
            attachedFileName = s.attachedFileName
        )

        val placeholder = ChatMessage(id = UUID.randomUUID().toString(), role = Role.ASSISTANT, text = "…", isStreaming = true)

        _state.update {
            it.copy(
                messages = it.messages + userMsg + placeholder,
                inputText = "",
                attachedFileName = null,
                attachedFileContent = null,
                isSending = true
            )
        }

        viewModelScope.launch(Dispatchers.IO) {
            val systemPrompt = buildSystemPrompt(s.mode, s.internetEnabled)
            val history = _state.value.messages.filterNot { it.id == placeholder.id }
            val result = aiRepository.chatCompletion(provider, model, systemPrompt, history)

            if (result.error != null) {
                _state.update { st ->
                    st.copy(
                        isSending = false,
                        messages = st.messages.map { m ->
                            if (m.id == placeholder.id) m.copy(text = "Ошибка запроса: ${result.error}", isStreaming = false) else m
                        }
                    )
                }
                return@launch
            }

            val parsed = if (s.mode == AiMode.BUILD) {
                FileOpParser.process(result.text, projectFiles)
            } else {
                ParsedAiResponse(result.text, emptyList())
            }

            if (parsed.actions.isNotEmpty()) refreshProjectTree()

            _state.update { st ->
                st.copy(
                    isSending = false,
                    messages = st.messages.map { m ->
                        if (m.id == placeholder.id) {
                            m.copy(text = parsed.displayText, fileActions = parsed.actions, isStreaming = false)
                        } else m
                    }
                )
            }
        }
    }

    private fun buildSystemPrompt(mode: AiMode, internet: Boolean): String {
        val treeInfo = if (_state.value.projectOpen) {
            "Открытая директория проекта: ${_state.value.projectRootName}\nФайлы:\n" +
                _state.value.projectNodes.joinToString("\n") { node ->
                    "  ".repeat(node.depth) + (if (node.isDirectory) "[папка] " else "") + node.name
                }
        } else {
            "Директория проекта не открыта. Файловые операции недоступны, пока пользователь не откроет папку."
        }

        val modeInstructions = when (mode) {
            AiMode.PLAN -> "Режим PLAN: только предлагай план действий и объясняй архитектуру. НЕ изменяй файлы — не выводи блоки ```fileop```."
            AiMode.BUILD -> """
                Режим BUILD: можешь создавать, изменять и удалять файлы в открытой директории проекта.
                Чтобы выполнить файловую операцию, выведи её как отдельный блок в формате:
                ```fileop
                {"action":"write","path":"относительный/путь/файл.ext","content":"полное новое содержимое файла"}
                ```
                Допустимые action: "create", "write" (перезаписать/создать), "delete" (path обязателен, content не нужен).
                Можно вывести несколько таких блоков подряд для нескольких файлов.
                Вне блоков ```fileop``` пиши обычный текст с объяснением для пользователя.
            """.trimIndent()
            AiMode.SEARCH -> "Режим SEARCH: отвечай так, будто у тебя есть доступ к актуальному поиску в интернете (если он включён), и указывай, что информацию стоит проверить, так как реального доступа к сети у модели может не быть."
        }

        val internetInstructions = if (internet) {
            "Доступ в интернет для пользователя ВКЛЮЧЁН — можешь рассуждать так, будто можешь ссылаться на внешние актуальные источники."
        } else {
            "Доступ в интернет ВЫКЛЮЧЕН — отвечай только на основе своих знаний, не утверждай, что проверил что-то в сети."
        }

        return """
            Ты — ИИ-ассистент внутри мобильной IDE "AI Coder IDE". Ты помогаешь писать и редактировать код.
            $modeInstructions
            $internetInstructions

            $treeInfo
        """.trimIndent()
    }
}
