package com.aicoder.ide.ui

import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource

/**
 * Every icon in this app is a vector drawable (SVG-style path data) under
 * res/drawable, loaded here through painterResource - no bitmap/PNG assets.
 */
@Composable
fun SvgIcon(resId: Int, modifier: Modifier = Modifier, contentDescription: String? = null) {
    Image(painter = painterResource(id = resId), contentDescription = contentDescription, modifier = modifier)
}
