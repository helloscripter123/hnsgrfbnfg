package com.aicoder.ide.data

import org.json.JSONObject

data class ParsedAiResponse(val displayText: String, val actions: List<FileAction>)

/**
 * The system prompt instructs the model to emit file operations as fenced
 * ```fileop blocks, e.g.:
 *
 * ```fileop
 * {"action":"write","path":"app/main.py","content":"print('hi')"}
 * ```
 *
 * This parser extracts every such block, executes it against the open
 * project directory, strips the raw block out of the text shown to the
 * user, and returns a summary of what happened so the UI can render it.
 */
object FileOpParser {

    private val blockRegex = Regex("```fileop\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)

    fun process(rawText: String, files: ProjectFiles): ParsedAiResponse {
        val actions = mutableListOf<FileAction>()
        val cleaned = blockRegex.replace(rawText) { match ->
            val jsonText = match.groupValues[1].trim()
            try {
                val obj = JSONObject(jsonText)
                val action = obj.optString("action")
                val path = obj.optString("path")
                when (action.lowercase()) {
                    "create" -> {
                        files.createFile(path, obj.optString("content", ""))
                        actions.add(FileAction(FileActionType.CREATE, path, "done"))
                    }
                    "write" -> {
                        val existing = files.findByRelativePath(path)
                        if (existing != null) {
                            files.writeFile(existing, obj.optString("content", ""))
                        } else {
                            files.createFile(path, obj.optString("content", ""))
                        }
                        actions.add(FileAction(FileActionType.WRITE, path, "done"))
                    }
                    "delete" -> {
                        val existing = files.findByRelativePath(path)
                        val ok = existing != null && files.deleteFile(existing)
                        actions.add(
                            FileAction(
                                FileActionType.DELETE,
                                path,
                                if (ok) "done" else "failed: not found"
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                actions.add(FileAction(FileActionType.WRITE, "?", "failed: ${e.message}"))
            }
            "" // strip the raw block from what the user sees
        }.trim()

        return ParsedAiResponse(cleaned.ifBlank { "Готово." }, actions)
    }
}
