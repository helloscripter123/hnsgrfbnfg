package com.aicoder.ide.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicoder.ide.R
import com.aicoder.ide.data.ProjectNode

private val TextMain = Color(0xFFE6E6EF)
private val TextMuted = Color(0xFF9090A0)
private val AccentBlue = Color(0xFF7C9BFF)

@Composable
fun DirectoryDrawerContent(
    state: UiState,
    onPickDirectory: () -> Unit,
    onOpenFile: (Uri, String) -> Unit,
    onDelete: (Uri) -> Unit,
    onCreateFile: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    var showNewFileDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxHeight().width(280.dp).padding(vertical = 16.dp)) {
        Text(
            "AI Coder IDE",
            color = TextMain,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(16.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onPickDirectory)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            SvgIcon(R.drawable.ic_folder, Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                if (state.projectOpen) "Проект: ${state.projectRootName}" else "Открыть директорию",
                color = if (state.projectOpen) TextMain else AccentBlue,
                fontSize = 13.sp
            )
        }

        if (state.projectOpen) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showNewFileDialog = true }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                SvgIcon(R.drawable.ic_add, Modifier.size(16.dp))
                Spacer(Modifier.width(10.dp))
                Text("Новый файл", color = TextMuted, fontSize = 12.sp)
            }

            Divider(color = Color(0xFF2A2A38), modifier = Modifier.padding(vertical = 8.dp))

            LazyColumn(Modifier.weight(1f)) {
                items(state.projectNodes) { node ->
                    FileTreeRow(node, onOpenFile, onDelete)
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
        }

        Divider(color = Color(0xFF2A2A38))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenSettings)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            SvgIcon(R.drawable.ic_settings, Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text("Настройки", color = TextMain, fontSize = 13.sp)
        }
    }

    if (showNewFileDialog) {
        NewFileDialog(
            onDismiss = { showNewFileDialog = false },
            onCreate = { path -> onCreateFile(path); showNewFileDialog = false }
        )
    }
}

@Composable
private fun FileTreeRow(node: ProjectNode, onOpenFile: (Uri, String) -> Unit, onDelete: (Uri) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !node.isDirectory) { onOpenFile(node.uri, node.name) }
            .padding(start = (16 + node.depth * 14).dp, end = 8.dp, top = 6.dp, bottom = 6.dp)
    ) {
        SvgIcon(if (node.isDirectory) R.drawable.ic_folder else R.drawable.ic_file, Modifier.size(15.dp))
        Spacer(Modifier.width(8.dp))
        Text(node.name, color = TextMain, fontSize = 12.sp, modifier = Modifier.weight(1f))
        if (!node.isDirectory) {
            IconButton(onClick = { onDelete(node.uri) }, modifier = Modifier.size(24.dp)) {
                SvgIcon(R.drawable.ic_delete, Modifier.size(14.dp))
            }
        }
    }
}

@Composable
private fun NewFileDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var path by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый файл") },
        text = {
            OutlinedTextField(
                value = path,
                onValueChange = { path = it },
                placeholder = { Text("например src/main.py") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { if (path.isNotBlank()) onCreate(path) }) { Text("Создать") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
