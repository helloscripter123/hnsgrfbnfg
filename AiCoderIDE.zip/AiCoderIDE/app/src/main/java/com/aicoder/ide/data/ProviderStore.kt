package com.aicoder.ide.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Stores the user's configured providers (with API keys) in private
 * SharedPreferences as JSON. Simple, dependency-free persistence.
 */
class ProviderStore(context: Context) {

    private val prefs = context.getSharedPreferences("ai_coder_providers", Context.MODE_PRIVATE)

    fun loadProviders(): List<Provider> {
        val raw = prefs.getString(KEY_PROVIDERS, null) ?: return emptyList()
        val arr = JSONArray(raw)
        val out = mutableListOf<Provider>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val modelsArr = o.getJSONArray("models")
            val models = (0 until modelsArr.length()).map { modelsArr.getString(it) }
            out.add(
                Provider(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    baseUrl = o.getString("baseUrl"),
                    apiKey = o.optString("apiKey", ""),
                    models = models
                )
            )
        }
        return out
    }

    fun saveProviders(providers: List<Provider>) {
        val arr = JSONArray()
        providers.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("baseUrl", p.baseUrl)
            o.put("apiKey", p.apiKey)
            o.put("models", JSONArray(p.models))
            arr.put(o)
        }
        prefs.edit().putString(KEY_PROVIDERS, arr.toString()).apply()
    }

    fun getSelectedModelKey(): String? = prefs.getString(KEY_SELECTED_MODEL, null)

    fun setSelectedModelKey(providerId: String, model: String) {
        prefs.edit().putString(KEY_SELECTED_MODEL, "$providerId::$model").apply()
    }

    fun getSavedTreeUri(): String? = prefs.getString(KEY_TREE_URI, null)

    fun setSavedTreeUri(uri: String) {
        prefs.edit().putString(KEY_TREE_URI, uri).apply()
    }

    companion object {
        private const val KEY_PROVIDERS = "providers_json"
        private const val KEY_SELECTED_MODEL = "selected_model"
        private const val KEY_TREE_URI = "tree_uri"
    }
}
