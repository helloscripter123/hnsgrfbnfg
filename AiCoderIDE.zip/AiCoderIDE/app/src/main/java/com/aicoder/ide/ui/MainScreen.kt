package com.aicoder.ide.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicoder.ide.R
import com.aicoder.ide.data.*

private val BgDark = Color(0xFF14141C)
private val SurfaceDark = Color(0xFF1E1E2A)
private val BubbleUser = Color(0xFF2C4BFF)
private val BubbleAi = Color(0xFF232330)
private val AccentBlue = Color(0xFF7C9BFF)
private val TextMain = Color(0xFFE6E6EF)
private val TextMuted = Color(0xFF9090A0)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    vm: MainViewModel,
    onPickDirectory: () -> Unit,
    onPickAttachment: () -> Unit
) {
    val state by vm.state.collectAsState()

    ModalNavigationDrawer(
        drawerState = rememberDrawerStateSync(state.drawerOpen, vm::toggleDrawer),
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = SurfaceDark) {
                DirectoryDrawerContent(
                    state = state,
                    onPickDirectory = onPickDirectory,
                    onOpenFile = { uri, name -> vm.openFileForViewing(uri, name) },
                    onDelete = vm::deleteNode,
                    onCreateFile = vm::createNewFile,
                    onOpenSettings = { vm.openSettings(true); vm.toggleDrawer() }
                )
            }
        }
    ) {
        Scaffold(
            containerColor = BgDark,
            topBar = {
                TopBar(
                    state = state,
                    onMenuClick = vm::toggleDrawer,
                    onModeSelect = vm::setMode,
                    onModelSelect = vm::selectModel,
                    onSettingsClick = { vm.openSettings(true) }
                )
            },
            bottomBar = {
                InputBar(
                    state = state,
                    onTextChange = vm::onInputChange,
                    onSend = vm::sendMessage,
                    onAttachClick = onPickAttachment,
                    onClearAttachment = vm::clearAttachment,
                    onToggleInternet = vm::toggleInternet
                )
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                ChatList(state.messages)
                state.errorMessage?.let { err ->
                    ErrorBanner(err, onDismiss = vm::clearError, modifier = Modifier.align(Alignment.TopCenter))
                }
            }
        }
    }

    if (state.settingsOpen) {
        SettingsSheet(
            state = state,
            onDismiss = { vm.openSettings(false) },
            onAddProvider = vm::addProvider,
            onRemoveProvider = vm::removeProvider
        )
    }

    state.openFileUri?.let {
        FileEditorDialog(
            fileName = state.openFileName.orEmpty(),
            content = state.openFileContent,
            onDismiss = vm::closeFileViewer,
            onSave = vm::saveOpenFile
        )
    }
}

/** Small bridge so a plain Boolean flag in our StateFlow can drive Material3's DrawerState. */
@Composable
private fun rememberDrawerStateSync(open: Boolean, onToggle: () -> Unit): DrawerState {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    LaunchedEffect(open) {
        if (open) drawerState.open() else drawerState.close()
    }
    LaunchedEffect(drawerState.currentValue) {
        val shouldBeOpen = drawerState.currentValue == DrawerValue.Open
        if (shouldBeOpen != open) onToggle()
    }
    return drawerState
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopBar(
    state: UiState,
    onMenuClick: () -> Unit,
    onModeSelect: (AiMode) -> Unit,
    onModelSelect: (String, String) -> Unit,
    onSettingsClick: () -> Unit
) {
    Column(Modifier.background(SurfaceDark)) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark, titleContentColor = TextMain),
            navigationIcon = {
                IconButton(onClick = onMenuClick) { SvgIcon(R.drawable.ic_menu, Modifier.size(22.dp)) }
            },
            title = {
                ModelPicker(state, onModelSelect)
            },
            actions = {
                IconButton(onClick = onSettingsClick) { SvgIcon(R.drawable.ic_settings, Modifier.size(22.dp)) }
            }
        )
        ModeSelector(state.mode, onModeSelect)
        Divider(color = Color(0xFF2A2A38))
    }
}

@Composable
private fun ModelPicker(state: UiState, onModelSelect: (String, String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val provider = state.providers.find { it.id == state.selectedProviderId }
    Box {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { expanded = true }
        ) {
            SvgIcon(R.drawable.ic_robot, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Column {
                Text(
                    state.selectedModel ?: "Нет модели",
                    color = TextMain,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (provider != null) {
                    Text(provider.name, color = TextMuted, fontSize = 11.sp)
                }
            }
            SvgIcon(R.drawable.ic_chevron_down, Modifier.size(16.dp))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            state.providers.forEach { p ->
                p.models.forEach { m ->
                    DropdownMenuItem(
                        text = { Text("${p.name}: $m") },
                        onClick = {
                            onModelSelect(p.id, m)
                            expanded = false
                        }
                    )
                }
            }
            if (state.providers.isEmpty()) {
                DropdownMenuItem(text = { Text("Добавьте провайдера в настройках") }, onClick = { expanded = false })
            }
        }
    }
}

@Composable
private fun ModeSelector(mode: AiMode, onSelect: (AiMode) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ModeChip("Plan", R.drawable.ic_plan, mode == AiMode.PLAN) { onSelect(AiMode.PLAN) }
        ModeChip("Build", R.drawable.ic_build, mode == AiMode.BUILD) { onSelect(AiMode.BUILD) }
        ModeChip("Search", R.drawable.ic_search, mode == AiMode.SEARCH) { onSelect(AiMode.SEARCH) }
    }
}

@Composable
private fun ModeChip(label: String, icon: Int, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) AccentBlue else Color(0xFF2A2A38)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        SvgIcon(icon, Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = if (selected) Color.White else TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun ChatList(messages: List<ChatMessage>) {
    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 10.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (messages.isEmpty()) {
            item { EmptyState() }
        }
        items(messages) { msg -> ChatBubble(msg) }
    }
}

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxWidth().padding(top = 60.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SvgIcon(R.drawable.ic_robot, Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text("Напишите ИИ, чтобы начать", color = TextMuted, fontSize = 14.sp)
    }
}

@Composable
private fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.role == Role.USER
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier
                .widthIn(max = 300.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (isUser) BubbleUser else Color(0xFF23232E))
                .padding(12.dp)
        ) {
            Text(
                text = if (msg.isStreaming) "…" else msg.text,
                color = TextMain,
                fontSize = 14.sp
            )
            if (msg.fileActions.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                msg.fileActions.forEach { action -> FileActionRow(action) }
            }
        }
    }
}

@Composable
private fun FileActionRow(action: FileAction) {
    val icon = when (action.type) {
        FileActionType.CREATE -> R.drawable.ic_add
        FileActionType.WRITE -> R.drawable.ic_edit
        FileActionType.DELETE -> R.drawable.ic_delete
    }
    val ok = action.status == "done"
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF16161F))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        SvgIcon(icon, Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Text(action.path, color = TextMain, fontSize = 12.sp, modifier = Modifier.weight(1f))
        SvgIcon(if (ok) R.drawable.ic_check else R.drawable.ic_close, Modifier.size(14.dp))
    }
}

@Composable
private fun ErrorBanner(text: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .padding(10.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF3A1F1F))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Color(0xFFFFB4B4), fontSize = 12.sp, modifier = Modifier.weight(1f))
        IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
            SvgIcon(R.drawable.ic_close, Modifier.size(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InputBar(
    state: UiState,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onAttachClick: () -> Unit,
    onClearAttachment: () -> Unit,
    onToggleInternet: () -> Unit
) {
    Column(
        Modifier
            .background(SurfaceDark)
            .padding(8.dp)
    ) {
        state.attachedFileName?.let { name ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2A2A38))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                SvgIcon(R.drawable.ic_file, Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text(name, color = TextMain, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onClearAttachment, modifier = Modifier.size(20.dp)) {
                    SvgIcon(R.drawable.ic_close, Modifier.size(14.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            IconButton(onClick = onAttachClick) { SvgIcon(R.drawable.ic_attach, Modifier.size(20.dp)) }
            IconButton(onClick = onToggleInternet) {
                SvgIcon(
                    if (state.internetEnabled) R.drawable.ic_internet_on else R.drawable.ic_internet_off,
                    Modifier.size(20.dp)
                )
            }
            TextField(
                value = state.inputText,
                onValueChange = onTextChange,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp)),
                placeholder = { Text("Сообщение ИИ...", color = TextMuted) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF2A2A38),
                    unfocusedContainerColor = Color(0xFF2A2A38),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TextMain,
                    unfocusedTextColor = TextMain
                ),
                maxLines = 5
            )
            Spacer(Modifier.width(6.dp))
            IconButton(
                onClick = onSend,
                enabled = !state.isSending,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (state.isSending) Color(0xFF44445A) else AccentBlue)
            ) {
                if (state.isSending) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    SvgIcon(R.drawable.ic_send, Modifier.size(18.dp))
                }
            }
        }
    }
}
