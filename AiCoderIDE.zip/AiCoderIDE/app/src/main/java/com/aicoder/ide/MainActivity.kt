package com.aicoder.ide

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import com.aicoder.ide.ui.MainScreen
import com.aicoder.ide.ui.MainViewModel
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val openDirectoryLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) vm.openDirectory(uri)
    }

    private val attachFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val name = queryDisplayName(uri) ?: "файл"
            val content = try {
                contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input)).readText()
                } ?: ""
            } catch (e: Exception) {
                "// не удалось прочитать файл: ${e.message}"
            }
            vm.attachFile(name, content)
        }
    }

    private fun queryDisplayName(uri: android.net.Uri): String? {
        val cursor = contentResolver.query(uri, null, null, null, null) ?: return null
        cursor.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) return it.getString(idx)
        }
        return null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.restoreSavedDirectory()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF14141C))) {
                MainScreen(
                    vm = vm,
                    onPickDirectory = { openDirectoryLauncher.launch(null) },
                    onPickAttachment = { attachFileLauncher.launch(arrayOf("*/*")) }
                )
            }
        }
    }
}
