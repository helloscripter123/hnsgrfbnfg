package com.aicoder.ide.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiCallResult(val text: String, val error: String? = null)

/**
 * Talks to any OpenAI-compatible /chat/completions endpoint: OpenAI, Groq,
 * OpenRouter, or a self-hosted OpenAI-compatible server. Same request shape
 * for all of them - only the base URL, key and model differ.
 */
class AiRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun chatCompletion(
        provider: Provider,
        model: String,
        systemPrompt: String,
        history: List<ChatMessage>
    ): AiCallResult {
        return try {
            val messages = JSONArray()
            messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
            history.forEach { m ->
                val roleStr = when (m.role) {
                    Role.USER -> "user"
                    Role.ASSISTANT -> "assistant"
                    Role.SYSTEM -> "system"
                    Role.TOOL -> "user"
                }
                messages.put(JSONObject().put("role", roleStr).put("content", m.text))
            }

            val body = JSONObject().apply {
                put("model", model)
                put("messages", messages)
                put("temperature", 0.4)
            }

            val request = Request.Builder()
                .url(provider.baseUrl.trimEnd('/') + "/chat/completions")
                .addHeader("Authorization", "Bearer ${provider.apiKey}")
                .addHeader("Content-Type", "application/json")
                // OpenRouter recommends these but they're ignored elsewhere:
                .addHeader("HTTP-Referer", "https://aicoder.ide")
                .addHeader("X-Title", "AI Coder IDE")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { resp ->
                val bodyStr = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return AiCallResult("", error = "HTTP ${resp.code}: ${bodyStr.take(400)}")
                }
                val json = JSONObject(bodyStr)
                val content = json.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                AiCallResult(content)
            }
        } catch (e: Exception) {
            AiCallResult("", error = e.message ?: "unknown error")
        }
    }
}
