package com.aicoder.ide.data

/**
 * An OpenAI-compatible provider. OpenAI, Groq and OpenRouter (and any other
 * OpenAI-compatible endpoint) all speak the same /chat/completions protocol,
 * so one class covers all of them - only baseUrl/model differ.
 */
data class Provider(
    val id: String,
    val name: String,
    val baseUrl: String,     // e.g. https://api.openai.com/v1
    val apiKey: String,
    val models: List<String> // model ids offered by this provider
)

enum class AiMode(val label: String) {
    PLAN("Plan"),
    BUILD("Build"),
    SEARCH("Search")
}

enum class Role { USER, ASSISTANT, SYSTEM, TOOL }

/** A single file action the AI performed on the open project directory. */
data class FileAction(
    val type: FileActionType,
    val path: String,
    val status: String // e.g. "done", "failed: ..."
)

enum class FileActionType { CREATE, WRITE, DELETE }

data class ChatMessage(
    val id: String,
    val role: Role,
    val text: String,
    val fileActions: List<FileAction> = emptyList(),
    val attachedFileName: String? = null,
    val isStreaming: Boolean = false
)

/** Well-known provider presets shown when the user adds a new provider. */
object ProviderPresets {
    val OPENAI = Provider(
        id = "preset-openai",
        name = "OpenAI",
        baseUrl = "https://api.openai.com/v1",
        apiKey = "",
        models = listOf("gpt-4o", "gpt-4o-mini", "gpt-4.1", "o3-mini")
    )
    val GROQ = Provider(
        id = "preset-groq",
        name = "Groq",
        baseUrl = "https://api.groq.com/openai/v1",
        apiKey = "",
        models = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768")
    )
    val OPENROUTER = Provider(
        id = "preset-openrouter",
        name = "OpenRouter",
        baseUrl = "https://openrouter.ai/api/v1",
        apiKey = "",
        models = listOf(
            "anthropic/claude-3.5-sonnet",
            "openai/gpt-4o",
            "google/gemini-2.0-flash-exp",
            "meta-llama/llama-3.3-70b-instruct"
        )
    )

    val ALL = listOf(OPENAI, GROQ, OPENROUTER)
}
